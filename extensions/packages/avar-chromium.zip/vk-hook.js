/**
 * Page-world hook: capture VK CDN video URLs from the player DOM and media element src changes.
 */
(function () {
  if (window.__avarVkHookInstalled) {
    return;
  }
  window.__avarVkHookInstalled = true;

  const VK_CDN_RE = /(?:^|\.)(?:vkuser\.net|okcdn\.ru|mycdn\.me)$/i;
  const VK_URL_RE =
    /https?:\/\/[^"'\s<>\\]+(?:vkuser\.net|okcdn\.ru|mycdn\.me)\/?[^"'\s<>\\]*/gi;
  const VK_TEXT_HINT_RE =
    /vkuser\.net|okcdn\.ru|mycdn\.me|mp4_\d+|["']sig["']\s*:|&sig=|&expires=/i;

  function shouldScanText(text) {
    return typeof text === "string" && VK_TEXT_HINT_RE.test(text);
  }

  function isVkCdnUrl(url) {
    if (!url || typeof url !== "string") {
      return false;
    }
    try {
      return VK_CDN_RE.test(new URL(url, location.href).hostname) && url.includes("sig=");
    } catch {
      return false;
    }
  }

  function postUrls(urls) {
    const unique = [...new Set(urls.filter(isVkCdnUrl))];
    if (unique.length > 0) {
      window.postMessage({ type: "avar-vk-media", urls: unique }, "*");
    }
  }

  function scanText(text) {
    if (!text) {
      return [];
    }
    const found = [];
    VK_URL_RE.lastIndex = 0;
    let match;
    while ((match = VK_URL_RE.exec(text)) !== null) {
      found.push(match[0].replace(/\\\//g, "/"));
    }
    return found;
  }

  function collectVideoSources() {
    const urls = [];
    document.querySelectorAll("video source[src], video[src]").forEach((el) => {
      const src = el.getAttribute("src") || el.src;
      if (src) {
        urls.push(src);
      }
    });
    document.querySelectorAll("video").forEach((video) => {
      if (video.currentSrc) {
        urls.push(video.currentSrc);
      }
    });
    return urls;
  }

  function reportDomSources() {
    postUrls(collectVideoSources());
  }

  function hookSrcProperty(proto, label) {
    const descriptor = Object.getOwnPropertyDescriptor(proto, "src");
    if (!descriptor?.set || !descriptor?.get) {
      return;
    }
    Object.defineProperty(proto, "src", {
      configurable: true,
      enumerable: descriptor.enumerable,
      get() {
        return descriptor.get.call(this);
      },
      set(value) {
        if (typeof value === "string" && isVkCdnUrl(value)) {
          postUrls([value]);
        }
        return descriptor.set.call(this, value);
      },
    });
  }

  function hookSetAttribute(proto) {
    const original = proto.setAttribute;
    proto.setAttribute = function avarVkSetAttribute(name, value) {
      if (name === "src" && typeof value === "string" && isVkCdnUrl(value)) {
        postUrls([value]);
      }
      return original.call(this, name, value);
    };
  }

  hookSrcProperty(HTMLMediaElement.prototype, "media");
  if (typeof HTMLSourceElement !== "undefined") {
    hookSrcProperty(HTMLSourceElement.prototype, "source");
    hookSetAttribute(HTMLSourceElement.prototype);
  }
  hookSetAttribute(HTMLMediaElement.prototype);

  function isVkVideoPage() {
    const host = location.hostname;
    const path = location.pathname;
    return (
      (host.includes("vkvideo.ru") || host.endsWith("vk.com")) &&
      (/\/video[-_]/.test(path) || path.includes("/video/") || path.includes("video_ext.php"))
    );
  }

  function startDomObserver() {
    const observer = new MutationObserver(() => {
      reportDomSources();
    });
    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["src"],
    });

    const poll = setInterval(() => {
      if (
        document.querySelector(
          "video, .VideoPage__video, .videoplayer, [class*='VideoPage'] video",
        )
      ) {
        reportDomSources();
      }
    }, 250);

    window.addEventListener("pagehide", () => {
      clearInterval(poll);
      observer.disconnect();
    });

    reportDomSources();
  }

  if (isVkVideoPage()) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", startDomObserver, { once: true });
    } else {
      startDomObserver();
    }
  }

  const originalFetch = window.fetch;
  window.fetch = function avarVkFetchWrapper(...args) {
    const requestUrl = typeof args[0] === "string" ? args[0] : args[0]?.url;
    if (isVkCdnUrl(requestUrl)) {
      postUrls([requestUrl]);
    }
    return originalFetch.apply(this, args).then((response) => {
      if (!isVkVideoPage()) {
        return response;
      }
      const contentType = response.headers?.get?.("content-type") || "";
      if (/json|text\/plain|javascript|text\/html/i.test(contentType)) {
        response
          .clone()
          .text()
          .then((text) => {
            if (shouldScanText(text)) {
              postUrls(scanText(text));
            }
          })
          .catch(() => {});
      }
      return response;
    });
  };

  const originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function avarVkXhrOpen(method, url, ...rest) {
    if (isVkCdnUrl(url)) {
      postUrls([url]);
    }
    if (isVkVideoPage()) {
      this.addEventListener("load", function avarVkXhrLoad() {
        if (shouldScanText(this.responseText)) {
          postUrls(scanText(this.responseText));
        }
      });
    }
    return originalOpen.call(this, method, url, ...rest);
  };
})();
